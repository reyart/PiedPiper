﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptimizerEngine.FileSystem {

    public class ZpGame : ZpDirectory {

        public ZpGame(string path) : base(path) {
        }
    }
}
