namespace ObjectListViewDemo.Models {
    public enum MaritalStatus
    {
        Single,
        Married,
        Divorced,
        Partnered
    }
}